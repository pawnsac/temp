#include <iostream>

using namespace std;

int main()
{
cout << "lol";
return 0;
}

int redundant(){
return 99;
}



